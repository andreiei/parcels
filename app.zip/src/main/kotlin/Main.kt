fun main() {
    val application = Application()
    application()
}
